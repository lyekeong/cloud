        <!------------------------------------- Footer START ---------------------------------------------->

        <footer class="text-center text-white">
            <div class="container">
                <section class="">
                    <br>
                </section>
                <hr class="my-4" style="color: red" />

                <!-- Section: Text -->
                <section class="mb-2" style="color: red;">
                    <div class="row d-flex justify-content-center">
                        <div class="col-lg-8">
                            <p>
                                TARUMT Graduation Store – Your trusted platform for official gowns, memorable gifts, and exclusive graduation keepsakes. Celebrate your success with ease and style. 🎓 #ProudToBeTARUMT
                            </p>
                        </div>
                    </div>
                </section>
            </div>
            <div class="text-center p-2" style="background-color: red">
                © 2025 TARUMT Graduation Store |
                <a class="text-white" href="#">tarumtgradstore.edu.my</a>
            </div>
        </footer>

        <!------------------------------------- Footer END ---------------------------------------------->